var app = (function()
{
	// Application object.
	var app = {};

	
	return app;
})();

// app.initialize();
