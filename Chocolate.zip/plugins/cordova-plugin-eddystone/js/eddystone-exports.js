// File: eddystone-exports.js
//
// Export Eddystone JavaScript library (not needed really
// since it is already globally defined, is here if this
// would change in the future).
//

module.exports = window.evothings.eddystone;
